PisoPhone coin box firmware 3.5.6 - DEVELOPMENT builds (no flash encryption)
commit 0099ce901f9f

These are the builds a box in your own shop runs. They can be flashed again at any time (USB or the dashboard).
Each chip folder holds ONE merged image (flash it at 0x0 on the ESP32-C3, at 0x1000 on the classic ESP32) and the
separate files with their offsets, taken from the build's own partition table.

== esp32-c3-dev (ESP32-C3, flash 4 MB) ==
files and where they go:
  bootloader.bin   at 0x000000  (13248 bytes)
  partitions.bin   at 0x008000  (3072 bytes)
  boot_app0.bin    at 0x00e000  (8192 bytes)
  firmware.bin     at 0x010000  (1348752 bytes)
partition table of this build:
  name        type  subtype  offset      size        encrypted
  nvs         1     0x0002   0x00009000  0x00005000  no
  otadata     1     0x0000   0x0000e000  0x00002000  no
  app0        0     0x0010   0x00010000  0x001e0000  no
  app1        0     0x0011   0x001f0000  0x001e0000  no
  spiffs      1     0x0082   0x003d0000  0x00020000  no
  coredump    1     0x0003   0x003f0000  0x00010000  no

== esp32dev-dev (ESP32, flash 4 MB) ==
files and where they go:
  bootloader.bin   at 0x001000  (17536 bytes)
  partitions.bin   at 0x008000  (3072 bytes)
  boot_app0.bin    at 0x00e000  (8192 bytes)
  firmware.bin     at 0x010000  (1341232 bytes)
partition table of this build:
  name        type  subtype  offset      size        encrypted
  nvs         1     0x0002   0x00009000  0x00005000  no
  otadata     1     0x0000   0x0000e000  0x00002000  no
  app0        0     0x0010   0x00010000  0x001e0000  no
  app1        0     0x0011   0x001f0000  0x001e0000  no
  spiffs      1     0x0082   0x003d0000  0x00020000  no
  coredump    1     0x0003   0x003f0000  0x00010000  no

Flash a merged image (esptool 4.x, pip install esptool; replace COM3 / /dev/ttyUSB0 with your port):
  ESP32-C3 : python -m esptool --chip esp32c3 --port COM3 --baud 460800 write_flash 0x0 esp32-c3-dev/esp32-c3-dev-merged.bin
  ESP32    : python -m esptool --chip esp32   --port COM3 --baud 460800 write_flash 0x1000 esp32dev-dev/esp32dev-dev-merged.bin
This keeps the box's saved data only if you do not erase the flash first. A deliberate full wipe (revenue, secret, Wi-Fi) is
  python -m esptool --chip esp32c3 --port COM3 erase_flash

Check the files against SHA256SUMS before flashing. manifest.json lists the same offsets and sizes.
"firmware.bin" is the application alone (the file the dashboard's "Install update" takes). The updates the router and dashboard
install by themselves are signed with the owner's key and published separately; the app file in this zip is NOT signed.
