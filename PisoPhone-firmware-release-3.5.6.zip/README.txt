PisoPhone coin box firmware 3.5.6 - RELEASE builds, ENCRYPTED PARTITION LAYOUT (for flash encryption)
commit 0099ce901f9f

READ THIS FIRST. What this zip is and is not:
  * It holds the production builds as PLAIN files with the partition layout where every partition is flagged "encrypted".
  * It holds NO keys. The flash-encryption key and the Secure Boot key are made on YOUR computer, offline, one flash-encryption
    key per unit, and are never put in git, in CI or in a zip (docs/PROVISIONING_SOLD_UNIT.md, section 2).
  * Burning the eFuses cannot be undone. The procedure in docs/PROVISIONING_SOLD_UNIT.md (copied into this zip) has NOT yet been
    run on a board: its gates (GATE 1 the bootloader, GATE 2 the plain boot, GATE 3 the ciphertext check, and the NVS check)
    must pass on a sacrificial board before any unit you sell. Do not burn a unit for sale with these files until they have.
  * The bootloader here is PlatformIO's stock Arduino bootloader. It is built without Secure Boot and without in-place flash
    encryption support (GATE 1 in the guide). The route this zip is meant for is the one in step 7 of the guide: encrypt every
    image on your computer with the unit's key and write the encrypted files, so the chip's ROM decrypts them. Whether that
    boots, accepts a signed update and reverts a bad one is exactly what GATE 1 and the practice log are for.
  * Use the ESP32-C3 files for units you sell. The classic ESP32 supports Secure Boot V2 only from chip revision 3 and uses a
    different encryption method (see Espressif's flash encryption guide for the ESP32); those files are included for completeness
    and are NOT covered by the commands below.

== esp32-c3-production-encrypted (ESP32-C3, flash 4 MB) ==
files and where they go:
  bootloader.bin   at 0x000000  (12464 bytes)
  partitions.bin   at 0x008000  (3072 bytes)
  boot_app0.bin    at 0x00e000  (8192 bytes)
  firmware.bin     at 0x020000  (1348528 bytes)
partition table of this build:
  name        type  subtype  offset      size        encrypted
  nvs         1     0x0002   0x00009000  0x00005000  yes
  otadata     1     0x0000   0x0000e000  0x00002000  yes
  phy_init    1     0x0001   0x00010000  0x00001000  yes
  ota_0       0     0x0010   0x00020000  0x001c0000  yes
  ota_1       0     0x0011   0x001e0000  0x001c0000  yes
  spiffs      1     0x0082   0x003a0000  0x00060000  yes

== esp32dev-production-encrypted (ESP32, flash 4 MB) ==
files and where they go:
  bootloader.bin   at 0x001000  (17536 bytes)
  partitions.bin   at 0x008000  (3072 bytes)
  boot_app0.bin    at 0x00e000  (8192 bytes)
  firmware.bin     at 0x020000  (1341008 bytes)
partition table of this build:
  name        type  subtype  offset      size        encrypted
  nvs         1     0x0002   0x00009000  0x00005000  yes
  otadata     1     0x0000   0x0000e000  0x00002000  yes
  phy_init    1     0x0001   0x00010000  0x00001000  yes
  ota_0       0     0x0010   0x00020000  0x001c0000  yes
  ota_1       0     0x0011   0x001e0000  0x001c0000  yes
  spiffs      1     0x0082   0x003a0000  0x00060000  yes

Per-unit encryption on your computer (ESP32-C3; ESP-IDF's espsecure, pip install esptool). KEY is that unit's
flash_encryption_key.bin. Every offset below is the flash address of the file:
  espsecure.py encrypt_flash_data --aes_xts --keyfile KEY --address 0x0 --output enc/esp32-c3-production-encrypted-bootloader.bin esp32-c3-production-encrypted/bootloader.bin
  espsecure.py encrypt_flash_data --aes_xts --keyfile KEY --address 0x8000 --output enc/esp32-c3-production-encrypted-partitions.bin esp32-c3-production-encrypted/partitions.bin
  espsecure.py encrypt_flash_data --aes_xts --keyfile KEY --address 0xe000 --output enc/esp32-c3-production-encrypted-boot_app0.bin esp32-c3-production-encrypted/boot_app0.bin
  espsecure.py encrypt_flash_data --aes_xts --keyfile KEY --address 0x20000 --output enc/esp32-c3-production-encrypted-firmware.bin esp32-c3-production-encrypted/firmware.bin
Then flash the encrypted files at the same offsets, after the eFuse steps of the guide. Verify with the guide's section 5.

Before anything: check the files against SHA256SUMS. manifest.json lists the offsets and sizes.
